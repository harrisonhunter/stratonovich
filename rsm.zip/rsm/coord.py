#!/usr/bin/python
import sys, socket, time

replicas = map(int, sys.argv[1:])
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('', 0))
s.listen(4)
print "\nListening on port " + str(s.getsockname()[1]) + " ..."

while True:
    conn, addr = s.accept()
    msg = conn.recv(4096)
     # Below goes your code. You need to write between 5-10 lines of code.
     # If you are writing more, you are doing something wrong.
     # the variables replies and replicas should be used.
     # .... YOUR CODE HERE .....
    for i, port in enumerate(replicas):
        fd = socket.create_connection(('localhost', port))
        fd.send(msg + ' ' + time.strftime("#-%a,-%d-%b-%Y-%H:%M:%S-+0000\n", time.gmtime()))
        if i == 0: 
            conn.send(fd.recv(4096))
        fd.close()
    conn.close